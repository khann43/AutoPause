chrome.tabs.onActivated.addListener(
activeInfo=>{
    chrome.tabs.query({},function(tabs){
        tabs.forEach(tab=>{
            if (tab.id !==activeInfo.tabId){
                chrome.scripting.executeScript({
                    target:{tabId:tab.id},
                    function:pauseMedia
                } );
            }else{
                chrome.scripting.executeScript({
                    target:{tabId:tab.id},
                    function:resumeMedia
                });
            }
        } );
    });
});
function pauseMedia(){
  document.querySelectorAll("video,audio").forEach(media=>{
    if (!media.paused){
        media.pause();
        localStorage.setItem("pauseMedia","true");
    }
  });
}

function resumeMedia(){
    document.querySelectorAll("video,audio").forEach(media=>{
        if
(localStorage.getItem) ("pausedMedia"==="true")
 {
media.play();
localStorage.removeItem("pausedMedia");
}
    });
}